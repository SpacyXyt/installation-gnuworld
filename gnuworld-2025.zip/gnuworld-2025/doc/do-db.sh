#!/bin/bash

echo -e "\e[32m Creating CService DB ... \e[0m "


createdb --template=template0 -E=SQL_ASCII cservice


echo -e "\e[33m Import *.sql to CService DB \e[0m"


psql  cservice < cservice.sql  
psql cservice < cservice.config.sql
psql cservice < languages.sql
psql cservice < language_table.sql
psql cservice < greeting.sql
psql cservice < cservice.help.sql
psql cservice < cservice.web.sql
psql cservice < cservice.addme.sql
echo  "-----"
echo  " "
echo -e "\e[32m Creating local_db ...\e[0m"
createdb local_db
echo -e "\e[33m Import *.sql to local_db\e[0m"
psql local_db < local_db.sql
echo  "-----"
echo  " "
echo -e "\e[32m Creating ccontrol DB ...\e[0m"
createdb --template=template0 -E=SQL_ASCII ccontrol
echo -e "\e[33m Import *.sql to ccontrol ...\e[0m"
psql ccontrol < ccontrol.sql
psql ccontrol < ccontrol.help.sql
psql ccontrol < ccontrol.addme.sql
psql ccontrol < ccontrol.commands.sql
echo  "-----"
echo  " "
echo -e "\e[32m Creating chanfix DB ...\e[0m"
createdb chanfix
echo -e "\e[33m Import *.sql to chanfix ...\e[0m"
psql chanfix < ../mod.openchanfix/doc/chanfix.sql
psql chanfix < ../mod.openchanfix/doc/chanfix.languages.sql
psql chanfix < ../mod.openchanfix/doc/chanfix.language.english.sql
psql chanfix < ../mod.openchanfix/doc/chanfix.help.sql
psql chanfix < ../mod.openchanfix/doc/chanfix.addme.sql
echo  "-----"
echo  " "
echo -e "\e[92m Congratulations! All DB are Create: \e[5mcservice, \e[5mlocal_db, \e[5mccontrol, \e[5mchanfix"
