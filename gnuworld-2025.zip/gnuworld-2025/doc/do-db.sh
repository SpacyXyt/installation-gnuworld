#!/bin/bash

# Script d'initialisation des bases de données
# Utilise l'utilisateur connecté (gnuworld) par défaut

# Fonctions d'affichage
log_info() {
    echo -e "\e[32m[INFO]\e[0m $1"
}

log_warn() {
    echo -e "\e[33m[WARN]\e[0m $1"
}

log_error() {
    echo -e "\e[31m[ERROR]\e[0m $1"
}

# Fonction pour vérifier l'existence d'un fichier
check_file() {
    if [ ! -f "$1" ]; then
        log_error "Fichier introuvable: $1"
        return 1
    fi
    return 0
}

# Fonction pour exécuter une commande avec gestion d'erreur
run_sql_command() {
    local db="$1"
    local sql_file="$2"
    
    if check_file "$sql_file"; then
        echo -e "  → Importation: \e[34m$(basename "$sql_file")\e[0m"
        if psql "$db" < "$sql_file" 2>/dev/null; then
            echo -e "    \e[32m✓ Succès\e[0m"
            return 0
        else
            echo -e "    \e[31m✗ Échec\e[0m"
            return 1
        fi
    fi
    return 1
}

# ----------------------------------------------------------------------
log_info "Création de la base CService..."

# Vérifier si la base existe déjà
if psql -l | grep -qw cservice; then
    log_warn "La base 'cservice' existe déjà. Voulez-vous la recréer? (o/N)"
    read -r response
    if [[ "$response" =~ ^[Oo]$ ]]; then
        echo "Suppression de l'ancienne base cservice..."
        dropdb cservice
        createdb --template=template0 -E=SQL_ASCII cservice
        log_info "Base cservice recréée."
    else
        log_info "Utilisation de la base cservice existante."
    fi
else
    createdb --template=template0 -E=SQL_ASCII cservice
    log_info "Base cservice créée."
fi

# Importation des fichiers SQL
log_info "Importation des fichiers SQL dans cservice..."
declare -a CSERVICE_FILES=(
    "cservice.sql"
    "cservice.config.sql"
    "languages.sql"
    "language_table.sql"
    "greeting.sql"
    "cservice.help.sql"
    "cservice.web.sql"
    "cservice.addme.sql"
)

for sql_file in "${CSERVICE_FILES[@]}"; do
    run_sql_command "cservice" "$sql_file"
done

echo "--------------------------------------------------"

# ----------------------------------------------------------------------
log_info "Création de la base local_db..."

if psql -l | grep -qw local_db; then
    log_warn "La base 'local_db' existe déjà. Voulez-vous la recréer? (o/N)"
    read -r response
    if [[ "$response" =~ ^[Oo]$ ]]; then
        dropdb local_db
        createdb local_db
        log_info "Base local_db recréée."
    else
        log_info "Utilisation de la base local_db existante."
    fi
else
    createdb local_db
    log_info "Base local_db créée."
fi

if check_file "local_db.sql"; then
    echo -e "  → Importation: \e[34mlocal_db.sql\e[0m"
    if psql local_db < local_db.sql 2>/dev/null; then
        echo -e "    \e[32m✓ Succès\e[0m"
    else
        echo -e "    \e[31m✗ Échec\e[0m"
    fi
fi

echo "--------------------------------------------------"

# ----------------------------------------------------------------------
log_info "Création de la base ccontrol..."

if psql -l | grep -qw ccontrol; then
    log_warn "La base 'ccontrol' existe déjà. Voulez-vous la recréer? (o/N)"
    read -r response
    if [[ "$response" =~ ^[Oo]$ ]]; then
        dropdb ccontrol
        createdb --template=template0 -E=SQL_ASCII ccontrol
        log_info "Base ccontrol recréée."
    else
        log_info "Utilisation de la base ccontrol existante."
    fi
else
    createdb --template=template0 -E=SQL_ASCII ccontrol
    log_info "Base ccontrol créée."
fi

log_info "Importation des fichiers SQL dans ccontrol..."
declare -a CCONTROL_FILES=(
    "ccontrol.sql"
    "ccontrol.help.sql"
    "ccontrol.addme.sql"
    "ccontrol.commands.sql"
)

for sql_file in "${CCONTROL_FILES[@]}"; do
    run_sql_command "ccontrol" "$sql_file"
done

echo "--------------------------------------------------"

# ----------------------------------------------------------------------
log_info "Création de la base chanfix..."

if psql -l | grep -qw chanfix; then
    log_warn "La base 'chanfix' existe déjà. Voulez-vous la recréer? (o/N)"
    read -r response
    if [[ "$response" =~ ^[Oo]$ ]]; then
        dropdb chanfix
        createdb chanfix
        log_info "Base chanfix recréée."
    else
        log_info "Utilisation de la base chanfix existante."
    fi
else
    createdb chanfix
    log_info "Base chanfix créée."
fi

log_info "Importation des fichiers SQL dans chanfix..."

# Chercher les fichiers chanfix dans différents répertoires
CHANFIX_DIR=""
for dir in "../mod.openchanfix/doc" "./mod.openchanfix/doc" "." ".."; do
    if [ -d "$dir" ] && [ -f "$dir/chanfix.sql" ]; then
        CHANFIX_DIR="$dir"
        break
    fi
done

if [ -n "$CHANFIX_DIR" ]; then
    log_info "Répertoire chanfix trouvé: $CHANFIX_DIR"
    
    declare -a CHANFIX_FILES=(
        "chanfix.sql"
        "chanfix.languages.sql"
        "chanfix.language.english.sql"
        "chanfix.help.sql"
        "chanfix.addme.sql"
    )
    
    for sql_file in "${CHANFIX_FILES[@]}"; do
        full_path="$CHANFIX_DIR/$sql_file"
        if check_file "$full_path"; then
            echo -e "  → Importation: \e[34m$sql_file\e[0m"
            if psql chanfix < "$full_path" 2>/dev/null; then
                echo -e "    \e[32m✓ Succès\e[0m"
            else
                echo -e "    \e[31m✗ Échec\e[0m"
            fi
        fi
    done
else
    log_error "Impossible de trouver les fichiers chanfix!"
    log_warn "Assurez-vous que mod.openchanfix/doc/ existe ou que les fichiers sont dans le répertoire courant."
fi

echo "--------------------------------------------------"

# Résumé final
log_info "Résumé de l'initialisation:"

echo -e "\n\e[36mBases de données disponibles:\e[0m"
for db in cservice local_db ccontrol chanfix; do
    if psql -l | grep -qw "$db"; then
        echo -e "\e[32m✓ $db\e[0m"
    else
        echo -e "\e[31m✗ $db (NON CRÉÉE)\e[0m"
    fi
done

echo -e "\n\e[92m──────────────────────────────────────────────────────\e[0m"
echo -e "\e[92m Initialisation terminée! \e[0m"
echo -e "\e[92m Bases créées: \e[5mcservice\e[0m, \e[5mlocal_db\e[0m, \e[5mccontrol\e[0m, \e[5mchanfix\e[0m"
echo -e "\e[92m──────────────────────────────────────────────────────\e[0m"

# Test de connexion rapide
echo -e "\n\e[36mTest de connexion aux bases:\e[0m"
for db in cservice local_db ccontrol chanfix; do
    if psql -l | grep -qw "$db"; then
        if psql "$db" -c "\dt" 2>/dev/null | head -5 &>/dev/null; then
            echo -e "  \e[32m✓ $db: Connexion OK\e[0m"
        else
            echo -e "  \e[33m⚠ $db: Connexion possible mais erreur de requête\e[0m"
        fi
    fi
done